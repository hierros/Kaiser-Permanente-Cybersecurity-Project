define([
    'jquery',
    'underscore',
    'api/SplunkVisualizationBase',
    'api/SplunkVisualizationUtils',
    'd3'
],
function(
    $,
    _,
    SplunkVisualizationBase,
    SplunkVisualizationUtils,
    d3
) {

return SplunkVisualizationBase.extend({

initialize: function() {
    // Save this.$el for convenience
    this.$el = $(this.el);
     
    // Add a css selector class
    this.$el.addClass('splunk-radial-meter');
},

getInitialDataParams: function() {
    return ({
        outputMode: SplunkVisualizationBase.ROW_MAJOR_OUTPUT_MODE,
        count: 10000
    });
},

updateView: function(data, config) {
    
	var dataRows = data.rows;
	
	//Grab the wanted view - if the viewTime_TF is No that means that the Timestamp View shouldn't be active and the Tactic View is active.
	// if the viewTime_TF is Yes that means that the Tactic View shouldn't be active and the Timestamp View should be active.
	var viewTime_TF = config[this.getPropertyNamespaceInfo().propertyNamespace+ 'viewTime_TF'] || "No";


	var maxCardStack = parseFloat(config[this.getPropertyNamespaceInfo().propertyNamespace+ 'axCardStack ']) || 20;


	if (maxCardStack != 20)
	{
		console.log('Card stack = ', maxCardStack); //DEBUGGING!!!
	}

	var tacticField;

    // Set height and width
    var margins = { top: 10, right: 10, bottom: 100, left: 50 }; // Define margins
    var width = 1500 - margins.left - margins.right; // Calculate width of the chart area
    var height = 300 - margins.top - margins.bottom; // Calculate height of the chart area



//Start of the massive switch statement to find the view that is wanted for the information.
if(viewTime_TF === "No") // START of Timestamp View of the attacks
{
	
	console.log('Tactic View is on True - Value = ', viewTime_TF); //DEBUGGING!!!
	
	console.log('Data from Splunk:', data); //DEBUGGING!!!

    for (var i = 0; i < data.fields.length; i++) {
        if (data.fields[i].name === "tactic") {
            tacticField = i;
            break;
        }
    }
    var tacticsArr = [];

    for (var i = 0; i < data.rows.length; i++) {

        tacticsArr.push(data.rows[i][tacticField]);
    }
    console.log('tacticField:', tacticField); //DEBUGGING!!!

    
    // check for data
    if (!dataRows || dataRows.length === 0 || dataRows[0].length === 0) {
        return this;
    }
             
    // Guard for empty data
    if(data.rows.length < 1){
        return;
    }


    // Clear the div
    this.$el.empty();

    	
//Static Tactic Field names
//    var tactics = ["Reconnaissance", "Resource Development", "Initial Access", "Execution", "Persistence", "Privilege Escalation", "Defense Evasion", //"Credential Access", "Discovery", "Lateral Movement", "Collection",
//        "Command and Control", "Exfiltration", "Impact"];


    console.log(tacticsArr); //DEBUGGING!!!
    
	//Create background 
    var chart = d3.select(this.el)
        .append("svg")
        .attr("width", width + margins.left + margins.right)
        .attr("height", height + margins.top + margins.bottom)
        .append("g")
        .attr("transform",
              "translate(" + margins.left + "," + margins.top + ")");
              
        chart.append("rect")
        .attr("x", -margins.left)
        .attr("y", -margins.top)
        .attr("width", "100%")
        .attr("height", "100%")
        .attr("fill", "#f4f4f4");
    
	// x axis
    var x = d3.scale.ordinal()
        .domain(tacticsArr)
        .rangeRoundBands([0, width], .1);
    
    chart.append("g")
        .attr("transform", "translate(0," + height + ")")
        .call(d3.svg.axis()
            .scale(x)
            .orient("bottom"))
            .selectAll('.tick text')
        .call(function(t){
            t.each(function(d){
                var self = d3.select(this);
                var s = self.text().split(" ");
                self.text('');
                self.append("tspan")
                    .attr("x", 0)
                    .attr("dy","1em")
                    .text(s[0]);
                self.append("tspan")
                    .attr("x", 0)
                    .attr("dy","1em")
                    .text(s[1]);
                self.append("tspan")
                    .attr("x", 0)
                    .attr("dy","1em")
                    .text(s[2]);
            })
        })
    
	
	// y axis
    var y = d3.scale.linear()
        .domain([0, maxCardStack])
        .range([height, 0]);
    
    chart.append("g")
        .call(d3.svg.axis()
            .scale(y)
            .orient("left"));
            
    chart.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", 0 - (height / 2))
        .attr("y", 0 - margins.left)
        .attr("dy", "1em")
        .style("text-anchor", "middle")
        .text("Technique Count");

    chart.selectAll("rect")
    .data(dataRows)
    .enter()
    .append("rect")
    .style("fill", "grey")
    .style("stroke", "black")
    .style("stroke-width", 1)
    .attr("width", 50)
    .attr("height", 20)  // Set height equal to the y-step size
    .attr("x", function(d) {
        return x(d[tacticField]); })
    .attr("y", 170);

} // END of Tactic View


// START of Timestamp View of the attacks
else
{
	console.log('Tactic View is on False - Value = ', viewTime_TF);
	
	//Fill in for data - this assigns columns for each variable wanted.
	for (var i = 0; i < data.fields.length; i++) {
        if (data.fields[i].name === "tactic") {
            tacticField = i;
            break;
        }
    }
    
	var tacticsArr = []; //Array for the attacks information


	//Fill in for attacks and their information.
    for (var i = 0; i < data.rows.length; i++) {

        tacticsArr.push(data.rows[i][tacticField]);
    }
    console.log('tacticField:', tacticField); //DEBUGGING!!!

    
    // check for data
    if (!dataRows || dataRows.length === 0 || dataRows[0].length === 0) {
        return this;
    }
             
    // Guard for empty data
    if(data.rows.length < 1){
        return;
    }

    // Clear the div
    this.$el.empty();

    
	
	//Static Tactic Field names
//    var tactics = ["Reconnaissance", "Resource Development", "Initial Access", "Execution", "Persistence", "Privilege Escalation", "Defense Evasion", //"Credential Access", "Discovery", "Lateral Movement", "Collection",
//        "Command and Control", "Exfiltration", "Impact"];


    console.log(tacticsArr); //DEBUGGING!!!
    
	//Create background 
    var chart = d3.select(this.el)
        .append("svg")
        .attr("width", width + margins.left + margins.right)
        .attr("height", height + margins.top + margins.bottom)
        .append("g")
        .attr("transform",
              "translate(" + margins.left + "," + margins.top + ")");
              
        chart.append("rect")
        .attr("x", -margins.left)
        .attr("y", -margins.top)
        .attr("width", "100%")
        .attr("height", "100%")
        .attr("fill", "#f4f4f4");
    
	// x axis
    var x = d3.scale.ordinal()
        .domain(tacticsArr)
        .rangeRoundBands([0, width], .1);
    
    chart.append("g")
        .attr("transform", "translate(0," + height + ")")
        .call(d3.svg.axis()
            .scale(x)
            .orient("bottom"))
            .selectAll('.tick text')
        .call(function(t){
            t.each(function(d){
                var self = d3.select(this);
                var s = self.text().split(" ");
                self.text('');
                self.append("tspan")
                    .attr("x", 0)
                    .attr("dy","1em")
                    .text(s[0]);
                self.append("tspan")
                    .attr("x", 0)
                    .attr("dy","1em")
                    .text(s[1]);
                self.append("tspan")
                    .attr("x", 0)
                    .attr("dy","1em")
                    .text(s[2]);
            })
        })
    
	
	// y axis
    var y = d3.scale.linear()
        .domain([0, maxCardStack])
        .range([height, 0]);
    
    chart.append("g")
        .call(d3.svg.axis()
            .scale(y)
            .orient("left"));
            
    chart.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", 0 - (height / 2))
        .attr("y", 0 - margins.left)
        .attr("dy", "1em")
        .style("text-anchor", "middle")
        .text("Attack Count");

    chart.selectAll("rect")
    .data(dataRows)
    .enter()
    .append("rect")
    .style("fill", "red")
    .style("stroke", "black")
    .style("stroke-width", 1)
    .attr("width", 50)
    .attr("height", 20)  // Set height equal to the y-step size
    .attr("x", function(d) {
        return x(d[tacticField]); })
    .attr("y", 170);
		
}//END of Timestamp View




    // fetch the next chunk after processing the current chunk
    this.offset += dataRows.length;
    this.updateDataParams({count: this.chunk, offset: this.offset}); 
    }
});
});